NOVÁ PROFESIONÁLNA VERZIA WEBU KOVACERIK.SK

1. Na GitHube otvor repozitár kovacerik.sk.
2. PONECHAJ celý existujúci priečinok assets bez zmeny.
3. Nahraj alebo nahraď tieto súbory v hlavnom priečinku repozitára:
   - index.html
   - style.css
   - script.js
   - robots.txt
   - sitemap.xml
   - CNAME
4. Klikni Commit changes.
5. Počkaj 1–3 minúty a otvor https://kovacerik.sk
6. Stlač Ctrl+F5.

Použité názvy médií v assets:
- 1000002503.jpg
- 1000002929.mp4
- 1000002005.mp4
- 1000000422.mp4
- 1000000419.mp4

Ak sa niektoré video nezobrazí, skontroluj, či má v priečinku assets presne rovnaký názov.

DÔLEŽITÉ K BOOKINGU:
Formulár momentálne pripraví e-mail na booking@kovacerik.sk.
Po aktivovaní tejto schránky bude kontakt plne použiteľný. Dovtedy môžeš v index.html nahradiť booking@kovacerik.sk svojou funkčnou adresou.
